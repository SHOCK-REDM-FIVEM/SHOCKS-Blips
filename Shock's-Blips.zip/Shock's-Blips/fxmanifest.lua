fx_version 'cerulean'
game 'gta5'

author 'SHOCK'
description 'Custom Blips'
version '2.0.0'
lua54 'yes'

client_script 'config.lua'
client_script 'blips.lua'

escrow_ignore {
    'config.lua'

}