local blips = {}

-- Function to create a blip
function createBlip(coords, sprite, color, scale, name)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, sprite)
    SetBlipColour(blip, color)
    SetBlipScale(blip, scale)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentSubstringPlayerName(name)
    EndTextCommandSetBlipName(blip)

    return blip
end

-- Create blips from the Config
Citizen.CreateThread(function()
    for _, blipInfo in ipairs(Config.Blips) do
        local blip = createBlip(blipInfo.coords, blipInfo.sprite, blipInfo.color, blipInfo.scale, blipInfo.name)
        table.insert(blips, blip)
    end
end)

-- Command to remove all blips
RegisterCommand("removeblips", function()
    for _, blip in ipairs(blips) do
        RemoveBlip(blip)
    end
    blips = {}
    TriggerEvent('chat:addMessage', {
        args = { "All blips removed." }
    })
end, false)