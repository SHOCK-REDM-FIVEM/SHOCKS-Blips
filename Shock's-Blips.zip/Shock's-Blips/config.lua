Config = {}

-- List of blips to be created
Config.Blips = {
    {
        coords = vector3(215.76, -810.12, 30.73), -- Example coordinates
        name = "Hospital",
        sprite = 61,    -- Blip sprite ID
        color = 2,      -- Blip color ID
        scale = 1.0     -- Blip size
    },
    {
        coords = vector3(-267.95, -957.38, 31.22), -- Example coordinates
        name = "Police Station",
        sprite = 60,    -- Blip sprite ID
        color = 3,      -- Blip color ID
        scale = 1.0     -- Blip size
    },
    {
        coords = vector3(1145.38, -1524.57, 34.38), -- Example coordinates
        name = "Custom Location",
        sprite = 1,     -- Blip sprite ID
        color = 5,      -- Blip color ID
        scale = 1.0     -- Blip size
    }
}